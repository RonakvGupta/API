﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using DA=DataAccessLayer;
using BE=BusinessEntity;
using System.Text;

namespace AngularProjectAPI.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class UserController : ApiController
    {
        DA.UserDal objUserDAL = null;
        BE.User RetriveUser = null;
        [HttpPost]
        public IHttpActionResult Login(BE.User objUser)
        {
            objUserDAL= new DA.UserDal();
            RetriveUser = objUserDAL.login(objUser);
            if (!string.IsNullOrEmpty(RetriveUser.uid.ToString()))
            {

                return Ok(new { result = RetriveUser });
            }

            throw new HttpResponseException(HttpStatusCode.NotFound);

        }
    }
}
